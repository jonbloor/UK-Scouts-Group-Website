cat > /home/ashby4th/htdocs/4thashby.org.uk/privacy.php <<'PHP'
<?php
declare(strict_types=1);
require __DIR__ . '/includes/config.php';
$pageTitle = 'Privacy policy';
require __DIR__ . '/partials/header.php';
?>

<section class="hero">
  <div class="container">
    <h1>Privacy policy</h1>
    <p class="lead">Placeholder page. You can add your final text later.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="card">
      <h2>Summary</h2>
      <p>Not specified.</p>
    </div>
  </div>
</section>

<?php require __DIR__ . '/partials/footer.php'; ?>
PHP
