<?php
// includes/config.php

declare(strict_types=1);

require __DIR__ . '/helpers.php';

/**
 * ============================================================
 * Site identity (single source of truth)
 * ============================================================
 */
$SITE = [
  'name'        => '4th Ashby Scout Group',
  'short_name'  => '4th Ashby Scouts',
  'subheading'  => 'Leicestershire',
  'tagline'     => 'Skills for life in Ashby de la Zouch, Donisthorpe, Oakthorpe, Smisby, Packington and Normanton le Heath for 4-18 year olds.',
  'url'         => 'https://4thashby.org.uk',
  'email'       => 'hello@4thashby.org.uk',
  'phone'       => '01530 888579',

  // Charity (optional, but required for full footer statement if enabled)
  'charity' => [
    'number'            => '1125053',
    'jurisdiction'      => 'England and Wales',
    'registered_name'   => '4th Ashby Scout Group',
    'registered_office' => 'Donisthorpe Scout Centre, 3 Church Street, Donisthorpe Swadlincote DE12 7PX',
    'register_url'      => 'https://register-of-charities.charitycommission.gov.uk/en/charity-search/-/charity-details/4040245',
  ],
];

/**
 * ============================================================
 * Social media links (displayed in footer "Follow us")
 * Key = platform slug (for icon class/filename)
 * Value = array with 'url' and optional 'label'
 * ============================================================
 */
$SOCIAL = [
  'x' => [
    'url' => 'https://x.com/4thashby',
    'label' => 'Follow us on X',
    'handle' => '4thashby',
  ],
  'facebook' => [
    'url' => 'https://www.facebook.com/4thAshby',
    'label' => 'Follow us on Facebook',
  ],
  'instagram' => [
    'url' => 'https://www.instagram.com/4thashby',
    'label' => 'Follow us on Instagram',
  ],
  'youtube' => [
    'url' => 'https://www.youtube.com/@yourchannel',
    'label' => 'Subscribe on YouTube',
  ],
  'pinterest' => [
    'url' => 'https://www.pinterest.com/4thashbyscouts/',
    'label' => 'Follow us on Pinterest',
  ],
  'linkedin' => [
    'url' => 'https://www.linkedin.com/company/4th-ashby-scout-group/',
    'label' => 'Follow us on LinkedIn',
  ],
];

/**
 * Social sharing / Open Graph defaults
 */
$SOCIAL_SHARING = [
    'default_image'      => '/assets/img/og-default.jpg',   // 1200×630 recommended
    'default_image_alt'  => $SITE['name'] . ' – Scouts in Ashby de la Zouch',
    'twitter_handle'     => '4thashby',                     // without @
    'image_width'        => 1200,
    'image_height'       => 630,
];

/**
 * ============================================================
 * Primary calls to action
 * ============================================================
 */
$CTA = [
  'join_url' => 'https://www.onlinescoutmanager.co.uk/waiting-list/4th-ashby-de-la-zouch-waiting-list/41903d51-9114-41c4-9d09-f2d69efb81b8/apply',
  'volunteer_url' => 'https://volunteeringopportunities.scouts.org.uk/',
  'donate_url' => '',
];

/**
 * ============================================================
 * Venue / area wording (homepage)
 * ============================================================
 */
$SITE['venue'] = [
  'name' => 'Donisthorpe Scout Centre',
  'area' => 'Ashby de la Zouch and nearby villages',
  'town' => 'Ashby de la Zouch',
];

/**
 * ============================================================
 * Brand / styling hooks
 * ============================================================
 */
$BRAND = [
  'logo_path' => '/assets/img/scouts-logo.svg',
  'logo_alt' => $SITE['name'],
  'accent_class' => 'brand-accent',
];

/**
 * ============================================================
 * Sections (age groups)
 * ============================================================
 */
$SECTIONS = [
  [
    'slug' => 'squirrels',
    'name' => 'Squirrels',
    'age' => '4–6 years',
    'colour' => '#ed3f23',
    'enabled' => true,
    'kind' => 'group',
    'url' => '/section.php?slug=squirrels',
    'logo' => __DIR__ . '/../assets/img/sections/squirrels.svg',
  ],
  [
    'slug' => 'beavers',
    'name' => 'Beavers',
    'age' => '6–8 years',
    'colour' => '#006ddf',
    'enabled' => true,
    'kind' => 'group',
    'url' => '/section.php?slug=beavers',
    'logo' => __DIR__ . '/../assets/img/sections/beavers.svg',
  ],
  [
    'slug' => 'cubs',
    'name' => 'Cubs',
    'age' => '8–10½ years',
    'colour' => '#23a950',
    'enabled' => true,
    'kind' => 'group',
    'url' => '/section.php?slug=cubs',
    'logo' => __DIR__ . '/../assets/img/sections/cubs.svg',
  ],
  [
    'slug' => 'scouts',
    'name' => 'Scouts',
    'age' => '10½–14 years',
    'colour' => '#004851',
    'enabled' => true,
    'kind' => 'group',
    'url' => '/section.php?slug=scouts',
    'logo' => __DIR__ . '/../assets/img/sections/scouts.svg',
  ],
  [
    'slug' => 'explorers',
    'name' => 'Explorers',
    'age' => '14–18 years',
    'colour' => '#003982',
    'enabled' => true,
    'kind' => 'district',
    'url' => '/section.php?slug=explorers',
    'logo' => __DIR__ . '/../assets/img/sections/explorers.svg',
  ],
  [
    'slug' => 'network',
    'name' => 'Network',
    'age' => '18–25 years',
    'colour' => '#7413dc',
    'enabled' => true,
    'kind' => 'district',
    'url' => '/section.php?slug=network',
    'logo' => __DIR__ . '/../assets/img/sections/network.svg',
  ],
];

/**
 * ============================================================
 * Icons / app icons (config-driven)
 * ============================================================
 */
$ICONS = [
  'favicon_ico' => '/assets/icons/favicon.ico',
  'favicon_16' => '/assets/icons/favicon-16x16.png',
  'favicon_32' => '/assets/icons/favicon-32x32.png',
  'favicon_96' => '/assets/icons/favicon-96x96.png',
  'apple_180' => '/assets/icons/apple-icon-180x180.png',
  'apple_152' => '/assets/icons/apple-icon-152x152.png',
  'apple_144' => '/assets/icons/apple-icon-144x144.png',
  'apple_120' => '/assets/icons/apple-icon-120x120.png',
  'apple_114' => '/assets/icons/apple-icon-114x114.png',
  'ms_tile_color' => '#ffffff',
  'ms_tile_image' => '/assets/icons/ms-icon-144x144.png',
  'theme_color' => '#ffffff',
];

/**
 * ============================================================
 * Navigation
 * ============================================================
 */
$NAV = [
  [
    'label' => 'About',
    'href'  => '/about.php',
    'children' => [
      ['label' => 'Policies', 'href' => '/policies.php'],
      ['label' => 'Annual reports', 'href' => '/annual-reports.php'],
    ],
  ],

  ['label' => 'Volunteering', 'href' => '/volunteer.php'],

  [
    'label' => 'Members',
    'href'  => '/members.php',
    'children' => [
      ['label' => 'Calendar', 'href' => '/calendar.php'],
      ['label' => 'Where we meet', 'href' => '/where-we-meet.php'],
      ['label' => 'Roll of honour', 'href' => '/roll-of-honour.php'],
      // later: ['label' => 'Gallery', 'href' => '/gallery.php'],
    ],
  ],

  ['label' => 'News', 'href' => '/news.php'],

  ['label' => 'Contact', 'href' => '/contact.php'],

  [
    'label' => 'Scout Centre Hire',
    'href'  => '/dsc.php',
    'show_in_nav' => false, // hide for now
  ],

  [
    'label' => 'Join',
    'href'  => '/join.php',
    'cta'   => true,
  ],
];


/**
 * ============================================================
 * Footer (fully config-driven; references $SITE/$CTA to avoid duplication)
 * ============================================================
 */
$FOOTER = [
  // Address line shown at bottom of footer (correspondence if different from charity registered_office)
  'address_line' => 'Donisthorpe Scout Centre, 3 Church Street, Donisthorpe Swadlincote DE12 7PX',
  // Full charity statement (rendered in footer.php using $SITE['charity'] directly)
  'show_charity_statement' => true,
  // Footer columns - each with 'title', 'type' ('sections' or 'links'), 'items' (arrays with 'label', optional 'href', 'slug', 'times')
  'columns' => [
    [
      'title' => 'Sections',
      'type' => 'sections',
      'items' => [
        ['label' => 'Squirrels', 'slug' => 'squirrels', 'times' => ['Mondays - 16:00 to 17:00', 'Wednesdays - 16:00 to 17:00']],
        ['label' => 'Beavers', 'slug' => 'beavers', 'times' => ['Tuesdays - 17:00 to 18:00', 'Thursdays - 17:00 to 18:00', 'Fridays - 17:00 to 18:00']],
        ['label' => 'Cubs', 'slug' => 'cubs', 'times' => ['Tuesdays - 18:00 to 19:30', 'Thursdays - 18:00 to 19:30']],
        ['label' => 'Scouts', 'slug' => 'scouts', 'times' => ['Tuesdays - 19:30 to 21:15', 'Thursdays - 19:30 to 21:15']],
        ['label' => 'Explorers', 'slug' => 'explorers', 'times' => ['Mondays - 19:30 to 21:15']],
      ],
    ],
    [
      'title' => 'Look Wider',
      'type' => 'links',
      'items' => [
        ['label' => 'The Scouts', 'href' => 'https://www.scouts.org.uk/'],
        ['label' => 'Leicestershire Scouts', 'href' => 'https://www.leicestershirescouts.org.uk'],
        ['label' => 'Ashby & Coalville Scouts', 'href' => 'https://www.ashbyandcoalvillescouts.org.uk'],
        ['label' => 'Willesley Scout Campsite', 'href' => 'https://www.willesley.org.uk'],
        ['label' => 'Ashby de la Zouch', 'href' => '#'],
      ],
    ],
    [
      'title' => 'Contact us',
      'type' => 'links',
      'items' => [
        ['label' => 'Contact Us', 'href' => '/contact.php'],
        ['label' => 'Join Us', 'href' => $CTA['join_url']],
        ['label' => 'Volunteer', 'href' => $CTA['volunteer_url']],
      ],
    ],
  ],
];

/**
 * ============================================================
 * Scout Centre / venue hire settings
 * ============================================================
 */
$HIRE = [
  'name' => 'Donisthorpe Scout Centre',
  'address' => 'Not specified',
  'rates' => [
    ['label' => 'Half day', 'price' => 50],
    ['label' => 'Full day', 'price' => 85],
    ['label' => 'Evening', 'price' => 120],
    ['label' => 'Overnight', 'price' => 180],
    ['label' => 'Weekend', 'price' => 400],
  ],
  'deposit_note' => '50% deposit required to secure a booking (unless waived by the Group).',
];

/**
 * ============================================================
 * Calendar settings
 * ============================================================
 */
$CALENDAR = [
  'db_path' => __DIR__ . '/../data/calendar.sqlite',
  'sources' => [
    ['name' => 'OSM Feed 325958', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=325958.OGU2M2Y4ZTVhZTYwN2Q2YzZlNGZkN2UzMTRhMTMxM2EzZTNhOGUzZTA1ZmFjMjY5YzE5OThhMjg1OGJhN2Y5NGI1Y2UxMjQzZTM5MjQyODg4MGU2ZmZkN2I0ODRlMDFiNDdjMTA5YjBlY2NlNWE5ZDNjZjQ4YmQwODBkNDY0NzA%3D.S83oMX7N7N7O'],
    ['name' => 'Riverbank Beavers', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=325957.OGI4ZWI1Y2RjZDdmYjg2MWNiZTdmNTIxMGEzYmExZmVkNmZiYWE0YzNjNzdlYjcwMDQ2OTc3YTA5NzdmZjViOWJkMWI4YWM1Nzg1ODhlN2Y1Y2RmZDY4NTNiYmJhNjBkOTY3Y2QwNzQzOWEyNjNlNDM1MjNkNGI4ZDBlNGFkMzI%3D.uiP6ykQjbf'],
    ['name' => 'OSM Feed 325960', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=325960.NTA5ZTg5OTRjNzcyMTEzMzllMjJkZTc0YjQxNDlhZGExZWU2ZTFlNGVkZmI2M2VjMGMxMTEzMDFhODAxZmQzZTNhNTllZDBlOGJlNjEwYjBiYzc5YTUwNzdkMzQ5OWVmYTk4YjJkYmQ1Njc1ZDM0ZDQzM2JjOGRkOWQyYmQzOTE%3D.oQrA9Yn75v'],
    ['name' => 'Woodland Beavers', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=325959.NTg3MTQ5MDA1MTViMGVlY2JlYTc5NGJkNWE2YjY4Njg0YTI0NGZhNmZhYTkyMTAxOTY4YmI1NmExZGUyZTIxMzhkYmI5YmMyNGE3Mjg3NThhNGFiMmI4MDhiZmI1NGQ4ZWNiZTNjMThhMjE5M2ZlMGQwYWE0ZTBiNDQ1MDgwOGQ%3D.jArsrLfe3b'],
    ['name' => 'OSM Feed 325952', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=325952.YTkzNGNjZTZmYTNlNTcyZDc1NGVmMjk5ZWVjMzM1YjM3NGNiOGRhNGU5NjA1YzkwMjk3MjI2ZGJhMDRkNjI2NDY5YzRiYjhmYWQ1NDQ2MGJjOTUwNTNkMmE2OTJmZmRmNzg1MTdmZjM5NDA3NzAwNTg5MTY1NmViOGY0NTY4NjU%3D.nBj0GyHqOJ'],
    ['name' => 'Waingunga Cubs', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=325951.ZjdlNjY3MzQ4ODFkNjY3NDBmMjFkOTEzZjIxZDJlNDNlZmIzNTY2Y2FlZmM2NzgyYWRlYmNmZGVhYjZiNmIxOGM1ZTIxMWRkYTA0ODA5YjcxNjE3YzBiNWMzZTM1NzJmYzhkOTE0NWI4YThmMjRmMDdjZTJmNzFmZDJhOTlhZWM%3D.WivaZTtIQ0'],
    ['name' => 'OSM Feed 325955', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=325955.YzljYzEyMTIzZTUxZjg3NjQ1ZGI2MDI1ZTc0NzM2Y2QzMGQ3YzY2NGRlYmE1MzVkYzQwMDhjOGU4ZjcwYzM2Y2Q4NDNlODU5MWEwMmMzYTg3ZjBkNzgxYjVlMDRhMjYxNjg0OTBkOWFhZTZjMzI2N2JjYzczMDI4ZDIzMmQ2YWI%3D.hW4sZAy92h'],
    ['name' => 'Seeonnee Cubs', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=325954.YjhiMDY2MmU2MTdhNDU3MmNhZTBhNDljYzc0NTA4NjU2NzE1ZjMxODBjMDg3YWEwYzE4NTEyODBkNGRiZTMyY2IzNzA5ZGU0NTA5YzMxZTlmMGRkOTIyZjgxMDQwNjQ5M2IyNzM1M2VhYTQxYTZhN2Q0YWIyYzk2MDkwOTI4NmM%3D.4RTso9Mlc0'],
    ['name' => 'OSM Feed 288490', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=288490.MjAzNTVmOTM1ZTQ0ZTNiMmZhNjhkYmQ1OTRmMWE5NjQxYzlkMzIyZmZmY2U1YzVlYWY1ZjgzMGQzMjI0ZDBmYjk0Mzg0NDg4MGUyNDM3MWI4NmU4NGY4YjMyNTI3ZmQ4ZjE3ZGJmN2I0NDZhMTY5ZWZkZTlmOGQ2NjdhMDA1YTE%3D.lwN3eIQwJh'],
    ['name' => 'OSM Feed 288489', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=288489.M2M5MTczOWY3Njk3ODNjYjYyMjFlZDAwZTQ3ZDE5NWJkYmM2ZTcwYTJmOTViZGY4MTg4MzNmYWRmNmZhODBmNzgzMTY3Njc1OGE4YjBlNmMzZWVkZTEwZmI2NzU4OGM5NDYxYTVmNGI1N2Q4ODk3Nzk0NGE3NzMyNjI2MTMzNzI%3D.YpNFcBiMzV'],
    ['name' => 'OSM Feed 288492', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=288492.ZDFkZTNjYWY3ZTBjOGM4NmI5NzFlNmY4MmZkMmE4OTc4OGUwNzQ0NDBkNTRhN2RjYzI0MTkwYzg4ODMyOTU5ODY0YWM3NWZmNDgyMmJlODk5YTZjZGU5ZjNjMmZhNzYyYTVjZTdkOGU3NjkyNzM4NDFjNjk3NjE0ZWNjMzNiYjU%3D.6W7bjcEHdJ'],
    ['name' => 'Challenger Scouts', 'url' => 'https://www.onlinescoutmanager.co.uk/ext/cal/?f=288491.NDQ2N2UzYzQwNmQyMTdjZTdkYTZjMGIwZmY1MDk5NDM0NmFmMTI1OWQ0MDNkYjk0OTYxMzBjYTMyZGFhZjVkZDBhMzMwNDZhMGU5OTQzYzZjM2RiZDMyNDE0ZTcwYjhiOTM0ZTVmMGM2NDkzMGZjMGQxZjA1NjA5OWM2M2ZlYmY%3D.lhOlwRFMfA'],
  ],
  'public_keywords' => ['open evening', 'agm', 'fundraiser', 'fete', 'coffee', 'car wash'],
  'public_uids' => [],
];

/**
 * ============================================================
 * Supporters / funders logos (homepage)
 * ============================================================
 */
$SUPPORTERS = [
  'items' => [
    // ['name' => 'Supporter Name', 'logo' => '/assets/img/supporters/example.svg', 'url' => 'https://example.org' - remove if not used],
    ['name' => 'Ashby Lions Club', 'logo' => '/assets/img/supporters/ashby-lions-club.svg',],
    ['name' => 'Leicestershire Scouts Forward 5 fund', 'logo' => '/assets/img/supporters/leicestershire-scouts-forward5.svg', 'url' => 'https://leicestershirescouts.org.uk'],
    ['name' => 'Ashby Rotary Clubs', 'logo' => '/assets/img/supporters/ashby-rotary-club.svg', 'url' => 'https://rotary-ribi.org/clubs/homepage.php?ClubID=401'],
    ['name' => 'LCC Choose How You Move', 'logo' => '/assets/img/supporters/chym.svg', 'url' => 'https://www.choosehowyoumove.co.uk/'],
    ['name' => 'Donisthorpe Reunion Band', 'logo' => '/assets/img/supporters/donisthorpe-reunion-band.svg',],
    ['name' => 'North West Leicestershire District Council', 'logo' => '/assets/img/supporters/nwldc.svg', 'url' => 'https://nwleics.gov.uk'],
    ['name' => 'The National Forest Company', 'logo' => '/assets/img/supporters/the-national-forest-company.svg', 'url' => 'https://www.nationalforest.org/']
    
  ],
  'max' => 0,
];